package com.eventure.eventure_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventureBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
